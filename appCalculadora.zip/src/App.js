import Button from './components/Button'
import './styleapp.css'

function App() {
  return (
    <div className="app">   
       <div className='itemApp'>
         <Button classeColor="darkgrey" numero="1"></Button>
         <Button classeColor="darkgrey"numero="2"></Button>
         <Button classeColor="darkgrey" numero="3"></Button>
         <Button classeColor="orange" numero="/"></Button>
        </div>   
        <div className='itemApp'>
         <Button classeColor="darkgrey"  numero="4"></Button>
         <Button classeColor="darkgrey" numero="5"></Button>
         <Button classeColor="darkgrey" numero="6"></Button>
         <Button classeColor="orange" numero="*"></Button>
        </div>
        <div className='itemApp'>
         <Button classeColor="darkgrey"  numero="7"></Button>
         <Button classeColor="darkgrey" numero="8"></Button>
         <Button classeColor="darkgrey" numero="9"></Button>
         <Button classeColor="orange" numero="+"></Button>
        </div>
        <div className='itemApp'>
         <Button classeColor="darkgrey" numero=""></Button>
         <Button classeColor="darkgrey" numero="0"></Button>
         <Button classeColor="darkgrey" numero="C"></Button>
         <Button classeColor="orange" numero="-"></Button>
        </div>      
       
    </div>
  );
}

export default App;
