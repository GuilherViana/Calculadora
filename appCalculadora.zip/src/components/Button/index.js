import React from 'react'
import './style.css'

function Button(props) {
    const classeAplicar = "btnNumero "+ props.classeColor 
    return (
      <div className={classeAplicar}>   
         <div>{props.numero}</div>             
      </div>
    );
  }
  
  export default Button;
  